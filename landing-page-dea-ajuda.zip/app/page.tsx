"use client"

import { Heart, Users, Smile, Cross } from "lucide-react"

export default function DEAAjudaPage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-gDu1drW8E0523EXqdmJIaahvjltxAd.png')`,
          }}
        />
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/75" />
        
        {/* Glow Effect behind logo */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
        
        {/* Content */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          {/* Logo Placeholder */}
          <div className="mb-8 flex justify-center">
            <div className="w-32 h-32 rounded-full bg-card border-4 border-primary flex items-center justify-center shadow-2xl shadow-primary/20">
              <span className="text-primary text-4xl font-bold">DEA</span>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-4 text-balance">
            <span className="text-primary">DEA</span> Ajuda
          </h1>
          <p className="text-2xl md:text-3xl font-light mb-6 text-foreground/90">
            Transformando Fé em Caridade
          </p>
          <p className="text-lg md:text-xl text-muted-foreground mb-10">
            O coração solidário do Grupo Deus é Amor.
          </p>
          
          <a
            href="#video"
            className="inline-flex items-center gap-3 bg-primary text-primary-foreground px-8 py-4 rounded-full font-semibold text-lg transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/30"
          >
            <span className="text-2xl">▶</span>
            Assistir nossa história
          </a>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-primary rounded-full" />
          </div>
        </div>
      </section>

      {/* Quem Somos Section */}
      <section className="py-24 px-4 bg-card">
        <div className="max-w-4xl mx-auto">
          <div className="bg-background border border-border rounded-2xl p-8 md:p-12 shadow-xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-primary text-center">
              DEA Ajuda
            </h2>
            <div className="space-y-6 text-lg leading-relaxed text-foreground/90">
              <p>
                O DEA Ajuda é o ministério social do Grupo Deus é Amor.
              </p>
              <p>
                Nascemos da certeza de que a fé não pode permanecer apenas nas palavras. Somos chamados a viver o Evangelho através de ações concretas que levam esperança, acolhimento e dignidade aos que mais precisam.
              </p>
              <p>
                Cada campanha, arrecadação, visita ou projeto realizado representa uma oportunidade de colocar em prática o amor ensinado por Cristo.
              </p>
              <p className="text-primary/80 italic">
                Inspirados por Nossa Senhora Auxiliadora, buscamos ser presença de cuidado, serviço e solidariedade na comunidade.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section id="video" className="py-24 px-4 bg-background">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Conheça nossa <span className="text-primary">missão</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-12">
            Assista ao vídeo e veja algumas das ações que marcaram nossa caminhada.
          </p>
          
          <div className="aspect-video bg-card border-2 border-primary/30 rounded-2xl overflow-hidden shadow-2xl">
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary text-4xl">▶</span>
                </div>
                <p className="text-muted-foreground">Vídeo em breve</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projetos Section */}
      <section className="py-24 px-4 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
            Projetos <span className="text-primary">Realizados</span>
          </h2>
          <p className="text-muted-foreground text-center mb-16 text-lg">
            Conheça algumas das ações que já desenvolvemos
          </p>
          
          <div className="grid md:grid-cols-2 gap-8">
            <ProjectCard
              emoji="🏃"
              title="Prova Rústica Tiradentes"
              description="Distribuímos água, apoio e incentivo aos atletas durante o evento, promovendo acolhimento e cuidado com todos os participantes."
            />
            <ProjectCard
              emoji="🍲"
              title="Sopão Solidário"
              description="Participamos do preparo e da distribuição de refeições para pessoas em situação de vulnerabilidade."
            />
            <ProjectCard
              emoji="🧥"
              title="Campanha do Agasalho"
              description="Mobilizamos jovens e famílias para arrecadar roupas e cobertores destinados a quem enfrenta o inverno com dificuldades."
            />
            <ProjectCard
              emoji="⚽"
              title="Figurinhas da Copa"
              description="Arrecadamos álbuns e figurinhas para proporcionar momentos de alegria a crianças que não tinham acesso ao material."
            />
          </div>
        </div>
      </section>

      {/* Nossa Inspiração Section */}
      <section className="relative py-32 px-4 overflow-hidden">
        {/* Background Image with partial visibility */}
        <div
          className="absolute inset-0 bg-contain bg-center bg-no-repeat opacity-15"
          style={{
            backgroundImage: `url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-4FoazRGOAGI7pMspjDhFGgdFaAcjY2.png')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
        
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">
            Nossa <span className="text-primary">Inspiração</span>
          </h2>
          <div className="space-y-6 text-lg leading-relaxed text-foreground/90">
            <p>
              Nossa Senhora Auxiliadora nos recorda que servir é uma forma de amar.
            </p>
            <p>
              Seu exemplo de entrega, humildade e disponibilidade inspira cada ação desenvolvida pelo ministério.
            </p>
            <p>
              Buscamos viver sua espiritualidade através da caridade, do acolhimento e do compromisso com aqueles que mais necessitam.
            </p>
          </div>
        </div>
      </section>

      {/* Nossos Valores Section */}
      <section className="py-24 px-4 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">
            Nossos <span className="text-primary">Valores</span>
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <ValueCard
              icon={<Heart className="w-10 h-10" />}
              title="Amor"
              description="Servir cada pessoa com dignidade."
            />
            <ValueCard
              icon={<Users className="w-10 h-10" />}
              title="Solidariedade"
              description="Compartilhar aquilo que recebemos."
            />
            <ValueCard
              icon={<Smile className="w-10 h-10" />}
              title="Alegria"
              description="Levar esperança através do sorriso."
            />
            <ValueCard
              icon={<Cross className="w-10 h-10" />}
              title="Evangelho"
              description="Anunciar Cristo através das ações."
            />
          </div>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-24 px-4 bg-background">
        <div className="max-w-4xl mx-auto text-center">
          <div className="text-6xl text-primary/30 mb-6">&ldquo;</div>
          <blockquote className="text-2xl md:text-3xl font-light leading-relaxed mb-8 text-foreground/90 text-balance">
            Não podemos todos fazer grandes coisas, mas podemos fazer pequenas coisas com muito amor.
          </blockquote>
          <cite className="text-lg text-primary font-medium">
            — Santa Teresa de Calcutá
          </cite>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-4 bg-card border-t border-border">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Cross className="w-6 h-6 text-primary" />
            <span className="text-2xl font-bold">Ministério DEA Ajuda</span>
          </div>
          <p className="text-muted-foreground mb-6">
            Uma iniciativa do Grupo Deus é Amor
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground mb-8">
            <span>Evangelização</span>
            <span className="text-primary">•</span>
            <span>Caridade</span>
            <span className="text-primary">•</span>
            <span>Acolhimento</span>
            <span className="text-primary">•</span>
            <span>Serviço</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2026 Ministério DEA Ajuda. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </main>
  )
}

function ProjectCard({
  emoji,
  title,
  description,
}: {
  emoji: string
  title: string
  description: string
}) {
  return (
    <div className="bg-background border border-border rounded-2xl p-8 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10">
      <div className="text-5xl mb-4">{emoji}</div>
      <h3 className="text-xl font-bold mb-3 text-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  )
}

function ValueCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="text-center">
      <div className="w-20 h-20 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center mx-auto mb-4 text-primary">
        {icon}
      </div>
      <h3 className="text-lg font-bold mb-2 text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
