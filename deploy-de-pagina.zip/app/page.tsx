import Image from "next/image"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0f0f12] text-[#f2f2f2]">
      {/* Hero Section */}
      <section
        className="min-h-screen flex justify-center items-center p-8 text-center bg-cover bg-center relative"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.72), rgba(0,0,0,0.82)), url('https://images.unsplash.com/photo-1519491050282-cf00c82424b4?auto=format&fit=crop&w=1600&q=80')`,
        }}
      >
        <div className="max-w-[900px]">
          <Image
            src="/logo-deus-e-amor.png"
            alt="Grupo Deus é Amor"
            width={180}
            height={180}
            className="mx-auto mb-6 rounded-full bg-white p-3 object-contain"
            style={{ boxShadow: "0 0 30px rgba(212,175,55,0.4)" }}
          />
          <h1 className="font-serif text-5xl md:text-7xl text-[#d4af37] leading-tight">
            Nossa Senhora Auxiliadora
          </h1>
          <p className="text-lg md:text-xl mt-4 leading-relaxed">
            Celebrada em 24 de Maio • Auxiliadora dos Cristãos
          </p>
          <p className="text-lg md:text-xl mt-2 leading-relaxed">
            {'"Maria, Auxiliadora dos Cristãos, rogai por nós."'}
          </p>
        </div>
      </section>

      {/* Content Container */}
      <div className="max-w-[1100px] w-[92%] mx-auto py-16">
        {/* Grupo Deus é Amor Card */}
        <Card variant="highlight">
          <h2 className="font-serif text-3xl md:text-4xl mb-5 text-[#d4af37]">
            Grupo Deus é Amor
          </h2>
          <p className="mb-4 leading-relaxed">
            Evangelizando jovens desde o ano 2000, o Grupo Deus é Amor nasceu
            com a missão de aproximar corações de Cristo através da oração, da
            fraternidade, da adoração e do encontro pessoal com Deus.
          </p>
          <p className="mb-4 leading-relaxed">
            Todas as quintas-feiras às 19h15, jovens e famílias se reúnem para
            viver momentos de espiritualidade, pregação, louvor e formação
            cristã.
          </p>
          <p className="leading-relaxed">
            Inspirados pelo amor de Deus e pela intercessão da Virgem Maria,
            buscamos construir uma juventude firme na fé e comprometida com o
            Evangelho.
          </p>
        </Card>

        {/* Quem é Nossa Senhora Card */}
        <Card>
          <h2 className="font-serif text-3xl md:text-4xl mb-5 text-[#d4af37]">
            Quem é Nossa Senhora Auxiliadora?
          </h2>
          <p className="mb-4 leading-relaxed">
            Nossa Senhora Auxiliadora é um dos títulos mais conhecidos e amados
            da Virgem Maria na Igreja Católica.
          </p>
          <p className="mb-4 leading-relaxed">
            A palavra &quot;Auxiliadora&quot; representa aquela que socorre,
            protege e acompanha os cristãos em suas necessidades espirituais e
            materiais.
          </p>
          <div className="border-l-4 border-[#d4af37] pl-5 my-5 italic text-[#f0d891]">
            Maria é reconhecida como Mãe que auxilia seus filhos e os conduz
            para mais perto de Jesus Cristo.
          </div>
        </Card>

        {/* Origem da Devoção Card */}
        <Card>
          <h2 className="font-serif text-3xl md:text-4xl mb-5 text-[#d4af37]">
            Origem da Devoção
          </h2>
          <p className="mb-4 leading-relaxed">
            A devoção ganhou força principalmente através de São João Bosco,
            fundador da Família Salesiana.
          </p>
          <p className="mb-4 leading-relaxed">
            Dom Bosco confiava profundamente na proteção de Nossa Senhora
            Auxiliadora e difundiu essa espiritualidade entre jovens, famílias e
            comunidades cristãs.
          </p>
          <p className="leading-relaxed">
            Em 1868 foi inaugurada a Basílica de Maria Auxiliadora em Turim, na
            Itália, tornando-se referência mundial para os devotos.
          </p>
        </Card>

        {/* Presença de Esperança Card */}
        <Card>
          <h2 className="font-serif text-3xl md:text-4xl mb-5 text-[#d4af37]">
            Uma Presença de Esperança
          </h2>
          <p className="mb-4 leading-relaxed">
            Ao longo dos séculos, milhares de testemunhos relataram graças
            alcançadas por meio da intercessão de Nossa Senhora Auxiliadora.
          </p>
          <p className="mb-4 leading-relaxed">
            Sua figura inspira confiança, perseverança, acolhimento e amor ao
            próximo.
          </p>
          <p className="leading-relaxed">
            Ela continua sendo exemplo de serviço, humildade e entrega total à
            vontade de Deus.
          </p>
        </Card>

        {/* DEA Ajuda Card */}
        <Card variant="highlight">
          <h2 className="font-serif text-3xl md:text-4xl mb-5 text-[#d4af37]">
            DEA Ajuda — Evangelizar através da Caridade
          </h2>
          <p className="mb-4 leading-relaxed">
            Inspirado pelos valores cristãos vividos pelo Grupo Deus é Amor e
            pela devoção a Nossa Senhora Auxiliadora, o Ministério DEA Ajuda
            busca transformar fé em ação.
          </p>
          <p className="mb-4 leading-relaxed">
            O ministério atua por meio de ações sociais, campanhas solidárias,
            arrecadações e projetos voltados para comunidades e casas de
            acolhida.
          </p>
          <p className="mb-4 leading-relaxed">
            Nossa missão é levar ajuda de forma concreta aos que mais precisam,
            oferecendo apoio material, acolhimento humano e a presença amorosa
            do Evangelho.
          </p>
          <p className="mb-4 leading-relaxed">
            Acreditamos que servir também é evangelizar.
          </p>
          <p className="mb-4 leading-relaxed">
            Por isso buscamos ajudar com amor, alegria e generosidade, tornando
            Cristo presente através da caridade, do cuidado e da fraternidade.
          </p>
          <p className="font-serif text-2xl md:text-3xl text-center mt-5 text-[#d4af37]">
            {'"Amar, acolher e servir: eis o caminho do Evangelho."'}
          </p>
          <div className="text-center mt-6">
            <a
              href="https://www.instagram.com/grupodeuseamor/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-7 py-3.5 rounded-full text-white font-semibold"
              style={{
                background: "linear-gradient(45deg, #f58529, #dd2a7b, #8134af)",
              }}
            >
              Acompanhe o Grupo Deus é Amor
            </a>
          </div>
        </Card>
      </div>

      {/* Footer */}
      <footer className="bg-black py-10 px-5 text-center">
        <div className="text-3xl text-[#d4af37] mb-3">✝</div>
        <Image
          src="/logo-deus-e-amor.png"
          alt="Grupo Deus é Amor"
          width={90}
          height={90}
          className="mx-auto mb-4 rounded-full"
        />
        <p className="text-lg font-semibold mb-2">Ministério DEA Ajuda</p>
        <p className="leading-relaxed">
          Evangelização • Ações Sociais • Casas de Acolhida • Caridade
        </p>
        <p className="opacity-80 text-sm mt-4">
          © 2026 Ministério DEA Ajuda. Todos os direitos reservados.
        </p>
      </footer>
    </main>
  )
}

function Card({
  children,
  variant = "default",
}: {
  children: React.ReactNode
  variant?: "default" | "highlight"
}) {
  const baseStyles =
    "p-6 md:p-10 rounded-2xl mb-8 border border-[rgba(212,175,55,0.15)]"
  const variantStyles =
    variant === "highlight"
      ? "bg-gradient-to-br from-[rgba(124,31,42,0.35)] to-[rgba(212,175,55,0.08)]"
      : "bg-[#1b1b20]"

  return (
    <div
      className={`${baseStyles} ${variantStyles}`}
      style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.25)" }}
    >
      {children}
    </div>
  )
}
